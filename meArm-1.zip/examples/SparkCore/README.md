meArm for Spark Core
====================
A quick and simple example to run your meArm with a Spark Core. See spark.io for more info on Spark Core.

Usage
-----
Simply use cURL requests to send commands to your meArm. Please have a look at the demo.sh file for a start!

Installation
------------
Clone this repository to your local machine, and copy and paste the code in the "ino" file to your Spark build editor
